Config = {}

Config.Key = 167

Config.AllowedJobs = {
    'mechanic'
}